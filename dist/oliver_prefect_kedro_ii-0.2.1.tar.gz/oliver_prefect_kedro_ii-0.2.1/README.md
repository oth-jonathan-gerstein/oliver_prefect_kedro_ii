# OTH Kedro Prefect Library


- Combines Kedro and Predect
- Works with Oliverto
- ✨Makes ETL Magic Happen✨

## Requirements

- Kedro
- Prefect
- Click
- Pendulum
- Pluggy